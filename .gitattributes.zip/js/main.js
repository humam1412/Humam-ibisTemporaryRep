
// var images = [
//   "../images/Untitled-1.jpg",
//   "../images/fotofooter.jpg",
//   "../images/Untitled-1.jpg" ]

//   var imageHead = document.getElementById("change-bg");
// var i = 0;

// setInterval(function() {
//       imageHead.style.backgroundImage = "url(" + images[i] + ")";
//       i = i + 1;
//       if (i == images.length) {
//       	i =  0;
//       }
// }, 1000);
  // Facts counter



$(function() {

	if ( $('.owl-2').length > 0 ) {
        $('.owl-2').owlCarousel({
            center: false,
            items: 1,
            loop: true,
            stagePadding: 0,
            margin: 20,
            smartSpeed: 1000,
            autoplay: true,
            nav: true,
            dots: true,
            pauseOnHover: false,
            responsive:{
                600:{
                    margin: 20,
                    nav: true,
                  items: 2
                },
                1000:{
                    margin: 20,
                    stagePadding: 0,
                    nav: true,
                  items: 3
                }
            }
        });            
    }

})